<footer class="footer">

   <section class="grid">

      <div class="box">
      <a href="home.php" class="logo"> <img width="200" height="60" src="images/logo1r.png"><span> </span></a>

         <div class="footer-container">
			<p>QuantumView, we strive to improve your quality of life at home through our exceptional brands, high-class products, and exceptional solutions.</p>						</div>

         <a href="https://www.facebook.com/QuantumView/"><i class="fab fa-facebook-f"></i>facebook</a>
        
         <a href="https://www.instagram.com/QuantumView/"><i class="fab fa-instagram"></i>instagram</a>
         <a href="https://www.youtube.com/channel/UCVrBZSIjL4UVA4IQlax9_sQ"><i class="fab fa-youtube"></i>Youtube</a>
             
        </div>
      </div>

      
      <div class="box">
      <h3>Information</h3>
      <div class="footer-container ">
							<strong >Corporate Office Address : </strong> QuantumView Headquarters- House: 27, Road: 35/A Badda, Dhaka-1212
<br>
<strong>Factory Address Comilla :</strong> 136/10, Dakhin Khan, Shashongachha, Comilla, Bangladesh
<br>
<a href="tel: 02-41081751"><i class="fa fa-phone" ></i>02-41081751 </a>
<a href="mailto: sauravpaljoy@gmail.com"><i class="fa fa-envelope" ></i>saurav_quantumviewbd@gmail.com </a>
<a href="mailto: parthadasapu@gmail.com"><i class="fa fa-envelope" ></i>partha_quantumviewbd@gmail.com </a>
</div>
</div>
<div class="box">
         <h3>Useful Links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> Home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> About</a>
         <a href="shop.php"> <i class="fas fa-angle-right"></i> Shop</a>
         <a href="user_login.php"> <i class="fas fa-angle-right"></i> Login</a>
         <a href="user_register.php"> <i class="fas fa-angle-right"></i> Register</a>
         <a href="contact.php"> <i class="fas fa-angle-right"></i> Contact</a>
        
      </div>

      
   </section>

   <div class="credit"> <span>  © 2023 Developed By Saurav & Partha  </span>All Rights Reserved.</div>

</footer>